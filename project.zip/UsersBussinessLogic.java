
	public class UsersBussinnessLogic implements UserBussiness {

	@Override
	public boolean registerUser(Users u) {
	if(	validateUser(u))
		System.out.println("user registred to successfully");
	else
		System.out.println("user registred to successfully");
		return false;
	}

	@Override
	public boolean updateUser() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Users[] SearchBySkills() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public boolean AuthenticateUser() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void ListEmployees(Users u) {
	System.out.println("Emp Id:"+u.getEmpId());
	System.out.println(" Name:"+u.getName());
	System.out.println(" DOB:"+u.getDOB());
	System.out.println(" Phoneno:"+u.getPhoneno());
	System.out.println(" Address:"+u.getAddress());
	System.out.println(" Qualification:"+u.getQualification());
	System.out.println(" EmailId:"+u.getEmailId());
	System.out.println(" Department:"+u.getDepartment());
	}}


